# Pocket YER
Simple offline personal expense tracker in Yemeni Rial.

## Build APK
Use GitHub Actions workflow from `.github/workflows/android.yml`. The project root is this directory and contains `settings.gradle.kts`.

Budget: Kebutuhan 22,000; Jajan 5,000; Kuota 3,000; Foya-foya 4,000; Cadangan 7,000 YER (total 41,000 YER).

Java and Kotlin JVM targets are both set to 21 to prevent JVM target mismatch.
