package com.pocketyer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private data class Expense(val amount: Int, val category: String, val note: String, val time: Long)
private val budgets = linkedMapOf("Kebutuhan" to 22000, "Jajan" to 5000, "Kuota" to 3000, "Foya-foya" to 4000, "Cadangan" to 7000)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketYerApp() }
    }
}


@Composable
private fun PocketYerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var expenses by remember {
        mutableStateOf(loadExpenses(context))
    }
    var showAdd by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    fun save(items: List<Expense>) { expenses = items; saveExpenses(context, items) }
    val spent = expenses.sumOf { it.amount }
    val remaining = 41000 - spent

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B54), secondary = androidx.compose.ui.graphics.Color(0xFFD4A84C))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Pocket YER", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = { showHistory = !showHistory }) { Text(if (showHistory) "Dashboard" else "Riwayat") } }) },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }
        ) { padding ->
            if (showHistory) {
                LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    item { Text("Riwayat pengeluaran", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(vertical = 12.dp)) }
                    if (expenses.isEmpty()) item { Text("Belum ada transaksi.") }
                    items(expenses.sortedByDescending { it.time }) { e ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(e.category, fontWeight = FontWeight.SemiBold); if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodySmall) }
                                Text("-${e.amount} YER", fontWeight = FontWeight.Bold)
                                TextButton(onClick = { save(expenses - e) }) { Text("Hapus") }
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
                    Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Sisa budget bulan ini", style = MaterialTheme.typography.titleMedium)
                            Text("${remaining} YER", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text("Terpakai: $spent / 41.000 YER")
                            LinearProgressIndicator(progress = { (spent / 41000f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                        }
                    }
                    Text("Budget kategori", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
                    budgets.forEach { (category, budget) ->
                        val catSpent = expenses.filter { it.category == category }.sumOf { it.amount }
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(category, fontWeight = FontWeight.SemiBold); Text("$catSpent / $budget YER") }
                                LinearProgressIndicator(progress = { (catSpent / budget.toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp))
                                Text("Sisa ${budget-catSpent} YER", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Text("Catatan: tabungan 110 ribu rupiah terpisah dari budget ini.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 14.dp))
                }
            }
        }
        if (showAdd) AddExpenseDialog(onDismiss = { showAdd = false }, onAdd = { e -> save(expenses + e); showAdd = false })
    }
}


@Composable
private fun AddExpenseDialog(onDismiss: () -> Unit, onAdd: (Expense) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Kebutuhan") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah pengeluaran") },
        text = {
            Column(Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState())) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Jumlah YER") }, singleLine = true)
                Text("Kategori", modifier = Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold)
                budgets.keys.forEach { c -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = category == c, onClick = { category = c }); Text(c) } }
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { val n = amount.toIntOrNull(); if (n != null && n > 0) onAdd(Expense(n, category, note, System.currentTimeMillis())) }, enabled = (amount.toIntOrNull() ?: 0) > 0) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun saveExpenses(context: android.content.Context, list: List<Expense>) {
    val array = JSONArray()
    list.forEach { e -> array.put(JSONObject().put("amount", e.amount).put("category", e.category).put("note", e.note).put("time", e.time)) }
    context.getSharedPreferences("pocketyer", 0).edit().putString("expenses", array.toString()).apply()
}
private fun loadExpenses(context: android.content.Context): List<Expense> {
    return try {
        val raw = context.getSharedPreferences("pocketyer", 0).getString("expenses", "[]") ?: "[]"
        val a = JSONArray(raw)
        (0 until a.length()).map { i -> val o = a.getJSONObject(i); Expense(o.getInt("amount"), o.getString("category"), o.optString("note", ""), o.optLong("time", 0)) }
    } catch (_: Exception) { emptyList() }
}
