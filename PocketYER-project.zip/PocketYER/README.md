# Pocket YER (Android project)

A simple offline-first expense tracker with monthly YER budgets.

## Default budget
- Kebutuhan: 22,000 YER
- Jajan: 5,000 YER
- Kuota: 3,000 YER
- Foya-foya: 4,000 YER
- Cadangan: 7,000 YER
- Total: 41,000 YER

## Build APK
1. Install Android Studio (stable) with Android SDK Platform 35.
2. Open this folder (`PocketYER`) in Android Studio.
3. Let Gradle sync/download dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK output is typically `app/build/outputs/apk/debug/app-debug.apk`.

Transactions are stored locally using SharedPreferences. No account, cloud, or internet permission is required.
