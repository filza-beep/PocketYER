package com.pocketyer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Pine = Color(0xFF143D32)
private val Mint = Color(0xFFB9E6CF)
private val Canvas = Color(0xFFF5F6F0)
private val Ink = Color(0xFF1D2824)
private val Muted = Color(0xFF78837B)
private val budgets = linkedMapOf("Kebutuhan" to 22000, "Jajan" to 5000, "Kuota" to 3000, "Foya-foya" to 4000, "Cadangan" to 7000)
private data class Tx(val id: Long, val amount: Int, val category: String, val note: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketTheme { PocketApp() } }
    }
}


@Composable
private fun PocketTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Pine, secondary = Mint, background = Canvas), content = content)
}


@Composable
private fun PocketApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pocket_yer", 0) }
    var transactions by remember { mutableStateOf(loadTx(prefs)) }
    var showAdd by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val thisMonth = transactions.filter { it.date.startsWith(month) }
    val total = thisMonth.sumOf { it.amount }
    val remaining = 41000 - total
    fun persist(list: List<Tx>) { transactions = list; saveTx(prefs, list) }

    Scaffold(
        containerColor = Canvas,
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Pine, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Tambah transaksi")
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Wallet, null) }, label = { Text("Ringkasan") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Riwayat") })
            }
        }
    ) { padding ->
        if (tab == 0) {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Text("Pocket YER", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Pine)
                    Text("Teman jaga uang bulananmu", color = Muted, fontSize = 14.sp)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Pine), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("SISA SALDO BULAN INI", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("${remaining.formatYER()} YER", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Budget 41.000", color = Color.White.copy(alpha = .78f))
                                Text("Terpakai ${total.formatYER()}", color = Color.White, fontWeight = FontWeight.SemiBold)
                            }
                            LinearProgressIndicator(progress = { (total.toFloat() / 41000f).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Mint, trackColor = Color.White.copy(alpha = .18f))
                        }
                    }
                }
                item { Text("Budget kategori", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink) }
                items(budgets.entries.toList()) { entry ->
                    val used = thisMonth.filter { it.category == entry.key }.sumOf { it.amount }
                    val left = entry.value - used
                    BudgetRow(entry.key, entry.value, used, left)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Dana cadangan", fontWeight = FontWeight.Bold, color = Ink)
                                Text("Usahakan jangan dipakai kecuali perlu", color = Muted, fontSize = 12.sp)
                            }
                            Text("7.000 YER", fontWeight = FontWeight.Bold, color = Pine)
                        }
                    }
                }
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Riwayat transaksi", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Pine); Text("Catatan uang keluar bulan ini", color = Muted) }
                if (thisMonth.isEmpty()) item { EmptyTransactions() }
                items(thisMonth.sortedByDescending { it.id }) { tx ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tx.note.ifBlank { tx.category }, color = Ink, fontWeight = FontWeight.Bold)
                                Text("${tx.category} · ${tx.date}", color = Muted, fontSize = 12.sp)
                            }
                            Text("-${tx.amount.formatYER()} YER", color = Color(0xFFB94B4B), fontWeight = FontWeight.Bold)
                            IconButton(onClick = { persist(transactions.filterNot { it.id == tx.id }) }) { Icon(Icons.Default.Delete, "Hapus", tint = Muted) }
                        }
                    }
                }
            }
        }
    }
    if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }, onSave = { tx -> persist(transactions + tx); showAdd = false })
}


@Composable
private fun BudgetRow(category: String, budget: Int, spent: Int, left: Int) {
    val pct = (spent.toFloat() / budget.toFloat()).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(category, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                Text("${left.formatYER()} YER tersisa", color = if (left < 0) Color(0xFFC64A4A) else Pine, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), color = if (left < 0) Color(0xFFD86B6B) else Pine, trackColor = Canvas)
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${spent.formatYER()} dipakai", color = Muted, fontSize = 12.sp)
                Text("Budget ${budget.formatYER()}", color = Muted, fontSize = 12.sp)
            }
        }
    }
}


@Composable
private fun EmptyTransactions() {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Belum ada transaksi", color = Ink, fontWeight = FontWeight.Bold)
            Text("Tekan tombol + untuk mulai mencatat pengeluaran", color = Muted, fontSize = 13.sp)
        }
    }
}


@Composable
private fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (Tx) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Kebutuhan") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah pengeluaran") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal (YER)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("Kategori", fontWeight = FontWeight.SemiBold)
                budgets.keys.forEach { name ->
                    Row(Modifier.fillMaxWidth().clickable { category = name }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = category == name, onClick = { category = name })
                        Text(name)
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { val n = amount.toIntOrNull(); if (n != null && n > 0) onSave(Tx(System.currentTimeMillis(), n, category, note, SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))) }, enabled = amount.toIntOrNull()?.let { it > 0 } == true) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}


private fun Int.formatYER(): String = String.format(Locale.US, "%,d", this)
private fun loadTx(prefs: android.content.SharedPreferences): List<Tx> {
    val raw = prefs.getString("transactions", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); Tx(o.getLong("id"), o.getInt("amount"), o.getString("category"), o.optString("note"), o.getString("date")) }
    } catch (_: Exception) { emptyList() }
}
private fun saveTx(prefs: android.content.SharedPreferences, list: List<Tx>) {
    val arr = JSONArray()
    list.forEach { tx -> arr.put(JSONObject().put("id", tx.id).put("amount", tx.amount).put("category", tx.category).put("note", tx.note).put("date", tx.date)) }
    prefs.edit().putString("transactions", arr.toString()).apply()
}
